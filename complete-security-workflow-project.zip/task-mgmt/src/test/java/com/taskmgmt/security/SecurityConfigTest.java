package com.taskmgmt.security;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureTestMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

/**
 * Security Configuration Tests
 * 
 * Tests security headers, CORS configuration, and authentication requirements
 */
@SpringBootTest
@AutoConfigureTestMvc
public class SecurityConfigTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testSecurityHeaders() throws Exception {
        mockMvc.perform(get("/users/login"))
                .andExpect(status().isOk())
                .andExpect(header().string("X-Frame-Options", "DENY"))
                .andExpect(header().string("X-Content-Type-Options", "nosniff"))
                .andExpect(header().exists("Strict-Transport-Security"));
    }

    @Test
    public void testCorsConfiguration() throws Exception {
        mockMvc.perform(get("/api/tasks")
                .header("Origin", "http://localhost:4200"))
                .andExpect(status().isUnauthorized()) // Should be unauthorized but CORS should work
                .andExpect(header().string("Access-Control-Allow-Origin", "http://localhost:4200"));
    }

    @Test
    public void testUnauthorizedAccess() throws Exception {
        mockMvc.perform(get("/api/tasks"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void testPublicEndpointsAccess() throws Exception {
        mockMvc.perform(get("/users/register"))
                .andExpect(status().isOk());
        
        mockMvc.perform(get("/users/login"))
                .andExpect(status().isOk());
    }

    @Test
    public void testStaticResourcesAccess() throws Exception {
        mockMvc.perform(get("/css/style.css"))
                .andExpect(status().isNotFound()); // 404 is fine, means no auth required
        
        mockMvc.perform(get("/js/app.js"))
                .andExpect(status().isNotFound()); // 404 is fine, means no auth required
    }

    @Test
    public void testCSRFDisabledForAPI() throws Exception {
        // CSRF should be disabled for stateless API
        mockMvc.perform(post("/api/tasks")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isUnauthorized()); // Should be unauthorized, not forbidden due to CSRF
    }

    @Test
    public void testInvalidJWTToken() throws Exception {
        mockMvc.perform(get("/api/tasks")
                .header("Authorization", "Bearer invalid-token"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void testMalformedJWTToken() throws Exception {
        mockMvc.perform(get("/api/tasks")
                .header("Authorization", "Bearer malformed.token"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void testEmptyAuthorizationHeader() throws Exception {
        mockMvc.perform(get("/api/tasks")
                .header("Authorization", ""))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void testBearerTokenWithoutToken() throws Exception {
        mockMvc.perform(get("/api/tasks")
                .header("Authorization", "Bearer "))
                .andExpect(status().isUnauthorized());
    }
}