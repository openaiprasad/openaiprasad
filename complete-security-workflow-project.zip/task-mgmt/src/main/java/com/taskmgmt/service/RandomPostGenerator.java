package com.taskmgmt.service;

public interface RandomPostGenerator {

}
