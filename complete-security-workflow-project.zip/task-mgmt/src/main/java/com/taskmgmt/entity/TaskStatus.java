package com.taskmgmt.entity;

public enum TaskStatus {

	OPEN,CLOSE
}
