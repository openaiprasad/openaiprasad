package com.taskmgmt.security;

import java.security.Key;
import java.util.Date;
import java.util.Map;
import java.util.function.Function;

import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

/**
 * Secure JWT Utility Service
 * 
 * Security improvements:
 * - Configurable secret key from environment variables
 * - Stronger signature algorithm (HS256 with proper key length)
 * - Configurable token expiration
 * - Enhanced error handling
 * - Token validation with proper exception handling
 * - Secure key generation and management
 */
@Service
public class SecureJwtUtil {

    @Value("${jwt.secret}")
    private String secretKey;

    @Value("${jwt.expiration:3600000}") // Default 1 hour
    private Long jwtExpiration;

    private static final String ISSUER = "task-mgmt-app";
    private static final SignatureAlgorithm SIGNATURE_ALGORITHM = SignatureAlgorithm.HS256;

    /**
     * Generate a secure signing key from the secret
     */
    private Key getSigningKey() {
        // Ensure the key is at least 256 bits for HS256
        byte[] keyBytes = secretKey.getBytes();
        if (keyBytes.length < 32) {
            // If the key is too short, use JJWT's secure key generation
            return Keys.secretKeyFor(SIGNATURE_ALGORITHM);
        }
        return new SecretKeySpec(keyBytes, SIGNATURE_ALGORITHM.getJcaName());
    }

    /**
     * Extract username from JWT token
     */
    public String extractUsername(String token) {
        try {
            return extractClaim(token, Claims::getSubject);
        } catch (JwtException e) {
            throw new SecurityException("Invalid JWT token: Unable to extract username", e);
        }
    }

    /**
     * Extract expiration date from JWT token
     */
    public Date extractExpiration(String token) {
        try {
            return extractClaim(token, Claims::getExpiration);
        } catch (JwtException e) {
            throw new SecurityException("Invalid JWT token: Unable to extract expiration", e);
        }
    }

    /**
     * Extract specific claim from JWT token
     */
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    /**
     * Extract all claims from JWT token with proper error handling
     */
    private Claims extractAllClaims(String token) {
        try {
            return Jwts.parserBuilder()
                    .setSigningKey(getSigningKey())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
        } catch (JwtException e) {
            throw new SecurityException("Invalid JWT token", e);
        }
    }

    /**
     * Check if token is expired
     */
    private Boolean isTokenExpired(String token) {
        try {
            return extractExpiration(token).before(new Date());
        } catch (Exception e) {
            // If we can't extract expiration, consider token invalid
            return true;
        }
    }

    /**
     * Generate JWT token with enhanced security
     */
    public String generateToken(String username, Map<String, Object> claims) {
        return createToken(claims, username);
    }

    /**
     * Create JWT token with proper security measures
     */
    private String createToken(Map<String, Object> claims, String subject) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + jwtExpiration);

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuer(ISSUER)
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .signWith(getSigningKey(), SIGNATURE_ALGORITHM)
                .compact();
    }

    /**
     * Validate JWT token with comprehensive checks
     */
    public Boolean validateToken(String token, UserDetails userDetails) {
        try {
            final String username = extractUsername(token);
            return (username.equals(userDetails.getUsername()) 
                    && !isTokenExpired(token)
                    && isTokenStructureValid(token));
        } catch (Exception e) {
            // Log security event (in production, use proper logging)
            System.err.println("JWT validation failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Additional validation for token structure
     */
    private boolean isTokenStructureValid(String token) {
        if (token == null || token.trim().isEmpty()) {
            return false;
        }
        
        // JWT should have 3 parts separated by dots
        String[] parts = token.split("\\.");
        if (parts.length != 3) {
            return false;
        }
        
        // Each part should not be empty
        for (String part : parts) {
            if (part.trim().isEmpty()) {
                return false;
            }
        }
        
        return true;
    }

    /**
     * Extract token from Authorization header
     */
    public String extractTokenFromHeader(String authHeader) {
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        return null;
    }

    /**
     * Check if token is about to expire (within 5 minutes)
     */
    public boolean isTokenAboutToExpire(String token) {
        try {
            Date expiration = extractExpiration(token);
            Date fiveMinutesFromNow = new Date(System.currentTimeMillis() + 5 * 60 * 1000);
            return expiration.before(fiveMinutesFromNow);
        } catch (Exception e) {
            return true; // If we can't determine, assume it's about to expire
        }
    }
}