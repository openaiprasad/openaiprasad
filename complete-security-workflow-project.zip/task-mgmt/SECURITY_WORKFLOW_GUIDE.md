# Security Workflow Implementation Guide

## Overview

This guide provides comprehensive documentation for the automated security scanning and remediation workflow implemented for the Task Management application. The workflow automates vulnerability detection, fix application, and pull request creation using multiple security tools.

## 🔧 Workflow Architecture

The security workflow consists of 6 main components:

1. **Repository Cloning** - Automated checkout of the latest code
2. **OSS Scanning** - Open Source Software vulnerability detection
3. **Snyk Scanning** - Commercial security analysis
4. **Automated PR Creation** - Pull requests for security fixes
5. **Report Generation** - Comprehensive security dashboards
6. **Notifications** - Team alerts and status updates

## 📁 File Structure

```
task-mgmt/
├── .github/workflows/
│   └── security-scan.yml           # GitHub Actions workflow
├── scripts/
│   ├── security-validation.sh      # Security validation script
│   ├── generate-security-report.py # Report generator
│   └── create-security-pr.sh       # PR automation script
├── security-config.yml             # Main security configuration
├── security-workflow.yml           # Workflow definition
├── .trivyignore                    # Trivy exclusions
├── .snyk                          # Snyk configuration
├── owasp-suppressions.xml         # OWASP suppressions
└── SECURITY_WORKFLOW_GUIDE.md     # This guide
```

## 🚀 Quick Start

### 1. Prerequisites

Ensure you have the following secrets configured in your GitHub repository:

```bash
# Required secrets
SNYK_TOKEN          # Snyk authentication token
SLACK_WEBHOOK_URL   # Slack notifications (optional)
GITHUB_TOKEN        # Automatically provided by GitHub
```

### 2. Enable the Workflow

The workflow is automatically triggered by:
- Push to `main` or `develop` branches
- Pull requests to `main`
- Daily schedule at 2 AM UTC
- Manual workflow dispatch

### 3. Manual Execution

To run the workflow manually:

```bash
# Using GitHub CLI
gh workflow run security-scan.yml

# Or trigger via GitHub web interface
# Go to Actions → Security Scanning and Remediation → Run workflow
```

## 🔍 Security Tools Integration

### Trivy Scanner
- **Purpose**: Container and filesystem vulnerability scanning
- **Configuration**: `.trivyignore`
- **Output**: SARIF and JSON reports
- **Severity**: CRITICAL, HIGH, MEDIUM

### pip-audit
- **Purpose**: Python dependency vulnerability scanning
- **Configuration**: Automatic detection of `requirements.txt`
- **Output**: JSON reports
- **Scope**: Python packages only

### OWASP Dependency Check
- **Purpose**: Java dependency vulnerability scanning
- **Configuration**: `owasp-suppressions.xml`
- **Output**: JSON and HTML reports
- **Integration**: Maven plugin

### Snyk
- **Purpose**: Comprehensive security analysis
- **Configuration**: `.snyk`
- **Scans**: Dependencies, code, containers, IaC
- **Output**: JSON reports with fix recommendations

## 📊 Report Generation

### HTML Dashboard

The workflow generates a comprehensive HTML security dashboard with:

- **Executive Summary**: Total vulnerabilities by severity
- **Interactive Charts**: Severity distribution and tool comparison
- **Detailed Tables**: Complete vulnerability listings
- **Dark/Light Themes**: Configurable appearance

### JSON Summary

Machine-readable summary including:
- Vulnerability counts by severity
- Tool-specific results
- Risk level assessment
- Scan metadata

### Example Usage

```bash
# Generate HTML report
python scripts/generate-security-report.py \
  --oss-results ./scan-results/oss-scan-results \
  --snyk-results ./scan-results/snyk-scan-results \
  --output security-dashboard.html \
  --theme dark

# Generate JSON summary
python scripts/generate-security-report.py \
  --oss-results ./scan-results/oss-scan-results \
  --snyk-results ./scan-results/snyk-scan-results \
  --output security-summary.json \
  --format json
```

## 🔄 Automated PR Creation

### OSS Fixes PR

Automatically created when OSS vulnerabilities are found:

- **Branch**: `security/oss-fixes-YYYYMMDD-HHMMSS`
- **Changes**: Dependency updates, security patches
- **Labels**: `security`, `automated`, `oss`
- **Status**: Draft by default

### Snyk Fixes PR

Automatically created when Snyk vulnerabilities are found:

- **Branch**: `security/snyk-fixes-YYYYMMDD-HHMMSS`
- **Changes**: Snyk-recommended fixes
- **Labels**: `security`, `automated`, `snyk`
- **Status**: Draft by default

### Manual PR Creation

```bash
# Create OSS fixes PR
./scripts/create-security-pr.sh --type oss --scan-dir ./scan-results

# Create Snyk fixes PR
./scripts/create-security-pr.sh --type snyk --reviewers "security-team,dev-lead"

# Create both types
./scripts/create-security-pr.sh --type all --draft --labels "security,urgent"
```

## ⚙️ Configuration Options

### Security Thresholds

Configure in `security-workflow.yml`:

```yaml
policies:
  vulnerability_thresholds:
    critical: 0      # Fail on any critical vulnerabilities
    high: 5          # Allow up to 5 high severity
    medium: 20       # Allow up to 20 medium severity
    low: 100         # Allow up to 100 low severity
```

### Auto-fix Rules

```yaml
auto_fix_rules:
  enabled: true
  max_changes_per_pr: 20
  require_tests: true
  allow_major_bumps: false
  min_severity: high
```

### Notification Settings

```yaml
notifications:
  slack:
    webhook: ${SLACK_WEBHOOK}
    channels: [security-alerts, dev-team]
    conditions: [critical_vulnerabilities_found, scan_failed]
```

## 🔧 Customization

### Adding New Security Tools

1. **Update GitHub Workflow**:
   ```yaml
   - name: Run Custom Scanner
     run: |
       custom-scanner --output custom-report.json
   ```

2. **Update Report Generator**:
   ```python
   def parse_custom_results(custom_file: str) -> Dict[str, Any]:
       # Parse custom scanner results
       pass
   ```

3. **Update PR Script**:
   ```bash
   apply_custom_fixes() {
       # Apply custom security fixes
   }
   ```

### Modifying Scan Scope

Edit tool configuration files:

- **Trivy**: Update `.trivyignore`
- **OWASP**: Update `owasp-suppressions.xml`
- **Snyk**: Update `.snyk`

### Custom Fix Logic

Modify `scripts/create-security-pr.sh`:

```bash
apply_oss_fixes() {
    # Add your custom fix logic here
    if [[ -f "custom-fixes.sh" ]]; then
        ./custom-fixes.sh
    fi
}
```

## 📈 Monitoring and Metrics

### Key Metrics

- **Vulnerability Count**: Total vulnerabilities by severity
- **Time to Fix**: Average time from detection to resolution
- **Scan Coverage**: Percentage of codebase scanned
- **False Positive Rate**: Ratio of false positives to true vulnerabilities

### Dashboard Access

- **GitHub Pages**: Automatically deployed security reports
- **Artifacts**: Download scan results and reports
- **Actions**: View workflow execution logs

### Alerting

Configure alerts for:
- Critical vulnerabilities found
- Scan failures
- PR creation
- Weekly summaries

## 🛠️ Troubleshooting

### Common Issues

1. **Scan Failures**
   ```bash
   # Check tool versions
   trivy --version
   snyk --version
   
   # Verify authentication
   snyk auth
   ```

2. **PR Creation Failures**
   ```bash
   # Check GitHub CLI authentication
   gh auth status
   
   # Verify repository permissions
   gh repo view
   ```

3. **Report Generation Issues**
   ```bash
   # Install missing dependencies
   pip install matplotlib plotly pandas
   
   # Check scan result files
   ls -la scan-results/
   ```

### Debug Mode

Enable debug logging:

```bash
# Set debug environment variable
export DEBUG=true

# Run with verbose output
./scripts/security-validation.sh -v
```

## 🔒 Security Considerations

### Secrets Management

- Store sensitive tokens in GitHub Secrets
- Use environment variables for configuration
- Never commit secrets to version control

### Access Control

- Limit workflow permissions to minimum required
- Use branch protection rules
- Require security team review for PRs

### Data Privacy

- Scan results may contain sensitive information
- Configure appropriate retention policies
- Use private repositories for sensitive projects

## 📚 Additional Resources

### Documentation
- [GitHub Actions Security](https://docs.github.com/en/actions/security-guides)
- [Trivy Documentation](https://aquasecurity.github.io/trivy/)
- [Snyk Documentation](https://docs.snyk.io/)
- [OWASP Dependency Check](https://owasp.org/www-project-dependency-check/)

### Best Practices
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework)
- [CIS Controls](https://www.cisecurity.org/controls/)

### Community
- [Security Community](https://github.com/topics/security)
- [DevSecOps](https://github.com/topics/devsecops)
- [Vulnerability Management](https://github.com/topics/vulnerability-management)

## 📞 Support

For issues or questions:

1. **Check Documentation**: Review this guide and related docs
2. **Run Validation**: Use `./scripts/security-validation.sh`
3. **Check Logs**: Review GitHub Actions logs
4. **Contact Team**: Reach out to security team

---

**Version**: 1.0  
**Last Updated**: 2025-12-13  
**Next Review**: 2026-01-13  
**Maintainer**: Security Team