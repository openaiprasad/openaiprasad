#!/bin/bash

# Security PR Creation Script
# Automates the creation of pull requests for security fixes

set -e

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BRANCH_PREFIX="security"
DEFAULT_REVIEWERS="security-team"
DEFAULT_LABELS="security,automated"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to show usage
show_usage() {
    cat << EOF
Usage: $0 [OPTIONS]

Create security fix pull requests based on scan results.

OPTIONS:
    -t, --type TYPE         Type of security fixes (oss|snyk|all)
    -s, --scan-dir DIR      Directory containing scan results
    -r, --reviewers LIST    Comma-separated list of reviewers
    -l, --labels LIST       Comma-separated list of labels
    -d, --draft             Create as draft PR
    -f, --force             Force creation even if no changes
    -h, --help              Show this help message

EXAMPLES:
    $0 --type oss --scan-dir ./scan-results
    $0 --type snyk --reviewers "security-team,dev-lead" --draft
    $0 --type all --labels "security,urgent,automated"

EOF
}

# Parse command line arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -t|--type)
                FIX_TYPE="$2"
                shift 2
                ;;
            -s|--scan-dir)
                SCAN_DIR="$2"
                shift 2
                ;;
            -r|--reviewers)
                REVIEWERS="$2"
                shift 2
                ;;
            -l|--labels)
                LABELS="$2"
                shift 2
                ;;
            -d|--draft)
                DRAFT_PR=true
                shift
                ;;
            -f|--force)
                FORCE_CREATE=true
                shift
                ;;
            -h|--help)
                show_usage
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                show_usage
                exit 1
                ;;
        esac
    done
}

# Validate arguments
validate_args() {
    if [[ -z "$FIX_TYPE" ]]; then
        log_error "Fix type is required. Use --type oss|snyk|all"
        exit 1
    fi
    
    if [[ "$FIX_TYPE" != "oss" && "$FIX_TYPE" != "snyk" && "$FIX_TYPE" != "all" ]]; then
        log_error "Invalid fix type: $FIX_TYPE. Must be oss, snyk, or all"
        exit 1
    fi
    
    # Set defaults
    SCAN_DIR="${SCAN_DIR:-./scan-results}"
    REVIEWERS="${REVIEWERS:-$DEFAULT_REVIEWERS}"
    LABELS="${LABELS:-$DEFAULT_LABELS}"
    DRAFT_PR="${DRAFT_PR:-true}"
    FORCE_CREATE="${FORCE_CREATE:-false}"
}

# Check if we're in a git repository
check_git_repo() {
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        log_error "Not in a git repository"
        exit 1
    fi
}

# Check if GitHub CLI is available
check_gh_cli() {
    if ! command -v gh &> /dev/null; then
        log_error "GitHub CLI (gh) is not installed or not in PATH"
        log_info "Install it from: https://cli.github.com/"
        exit 1
    fi
    
    # Check if authenticated
    if ! gh auth status &> /dev/null; then
        log_error "GitHub CLI is not authenticated"
        log_info "Run: gh auth login"
        exit 1
    fi
}

# Parse scan results to count vulnerabilities
parse_scan_results() {
    local scan_type="$1"
    local vuln_count=0
    
    case "$scan_type" in
        "oss")
            # Count Trivy vulnerabilities
            if [[ -f "$SCAN_DIR/trivy-report.json" ]]; then
                local trivy_count=$(jq '.Results[]?.Vulnerabilities // [] | length' "$SCAN_DIR/trivy-report.json" 2>/dev/null | awk '{sum+=$1} END {print sum+0}')
                vuln_count=$((vuln_count + trivy_count))
            fi
            
            # Count pip-audit vulnerabilities
            if [[ -f "$SCAN_DIR/pip-audit-report.json" ]]; then
                local pip_count=$(jq '.vulnerabilities | length' "$SCAN_DIR/pip-audit-report.json" 2>/dev/null || echo "0")
                vuln_count=$((vuln_count + pip_count))
            fi
            
            # Count OWASP vulnerabilities
            if [[ -f "$SCAN_DIR/dependency-check-report.json" ]]; then
                local owasp_count=$(jq '.dependencies[]?.vulnerabilities // [] | length' "$SCAN_DIR/dependency-check-report.json" 2>/dev/null | awk '{sum+=$1} END {print sum+0}')
                vuln_count=$((vuln_count + owasp_count))
            fi
            ;;
        "snyk")
            # Count Snyk vulnerabilities
            if [[ -f "$SCAN_DIR/snyk-report.json" ]]; then
                local snyk_count=$(jq '.vulnerabilities | length' "$SCAN_DIR/snyk-report.json" 2>/dev/null || echo "0")
                vuln_count=$((vuln_count + snyk_count))
            fi
            ;;
    esac
    
    echo "$vuln_count"
}

# Apply OSS security fixes
apply_oss_fixes() {
    log_info "Applying OSS security fixes..."
    
    local changes_made=false
    
    # Apply secure POM if available
    if [[ -f "pom-secure.xml" ]]; then
        log_info "Applying secure Maven dependencies..."
        cp pom-secure.xml pom.xml
        changes_made=true
    fi
    
    # Apply secure security configuration if available
    if [[ -f "src/main/java/com/taskmgmt/security/SecurityConfig.java" ]]; then
        log_info "Applying secure security configuration..."
        # SecurityConfig.java is already in place
        changes_made=true
    fi
    
    # Apply secure JWT utility if available
    if [[ -f "src/main/java/com/taskmgmt/security/SecureJwtUtil.java" ]]; then
        log_info "Applying secure JWT utility..."
        # SecureJwtUtil.java is already in place
        changes_made=true
    fi
    
    # Update application properties for security
    if [[ -f "src/main/resources/application-security.properties" ]]; then
        log_info "Applying security properties..."
        # Properties file is already in place
        changes_made=true
    fi
    
    echo "$changes_made"
}

# Apply Snyk security fixes
apply_snyk_fixes() {
    log_info "Applying Snyk security fixes..."
    
    local changes_made=false
    
    # Example: Apply Snyk-recommended dependency updates
    # This would typically involve parsing Snyk results and applying fixes
    # For now, we'll apply the secure POM as an example
    
    if [[ -f "pom-secure.xml" ]]; then
        log_info "Applying Snyk-recommended dependency updates..."
        cp pom-secure.xml pom.xml
        changes_made=true
    fi
    
    echo "$changes_made"
}

# Create a new branch for security fixes
create_security_branch() {
    local fix_type="$1"
    local timestamp=$(date +%Y%m%d-%H%M%S)
    local branch_name="${BRANCH_PREFIX}/${fix_type}-fixes-${timestamp}"
    
    log_info "Creating branch: $branch_name"
    
    # Ensure we're on the main branch
    git checkout main
    git pull origin main
    
    # Create and checkout new branch
    git checkout -b "$branch_name"
    
    echo "$branch_name"
}

# Commit changes
commit_changes() {
    local fix_type="$1"
    local vuln_count="$2"
    
    # Configure git user if not set
    if [[ -z "$(git config user.name)" ]]; then
        git config user.name "Security Bot"
    fi
    
    if [[ -z "$(git config user.email)" ]]; then
        git config user.email "security-bot@company.com"
    fi
    
    # Add all changes
    git add .
    
    # Create commit message
    local commit_msg="Security: Apply ${fix_type} vulnerability fixes

- Fixed ${vuln_count} security vulnerabilities
- Applied automated security patches
- Updated dependencies to secure versions

Auto-generated by security scanning workflow"
    
    git commit -m "$commit_msg"
}

# Create pull request
create_pull_request() {
    local fix_type="$1"
    local vuln_count="$2"
    local branch_name="$3"
    
    local pr_title="Security: ${fix_type^^} vulnerability fixes"
    local pr_body="This PR contains automated fixes for security vulnerabilities found by ${fix_type} scanning.

## Summary
- **Vulnerabilities Fixed:** ${vuln_count}
- **Scan Type:** ${fix_type^^}
- **Auto-generated:** Yes

## Changes
- Updated dependencies to secure versions
- Applied security patches and configurations
- Fixed identified security vulnerabilities

## Scan Results
Please review the attached scan results for detailed information about the vulnerabilities that were fixed.

## Testing
- [ ] Security tests pass
- [ ] Application builds successfully
- [ ] No regression in functionality

## Review Checklist
- [ ] All security fixes are appropriate
- [ ] No breaking changes introduced
- [ ] Dependencies are compatible
- [ ] Security configuration is correct

---
**Auto-generated by:** Security scanning workflow  
**Branch:** ${branch_name}  
**Timestamp:** $(date -u '+%Y-%m-%d %H:%M:%S UTC')"

    # Prepare gh command arguments
    local gh_args=(
        "pr" "create"
        "--title" "$pr_title"
        "--body" "$pr_body"
        "--base" "main"
        "--head" "$branch_name"
    )
    
    # Add reviewers
    if [[ -n "$REVIEWERS" ]]; then
        gh_args+=("--reviewer" "$REVIEWERS")
    fi
    
    # Add labels
    if [[ -n "$LABELS" ]]; then
        gh_args+=("--label" "$LABELS")
    fi
    
    # Add draft flag
    if [[ "$DRAFT_PR" == "true" ]]; then
        gh_args+=("--draft")
    fi
    
    log_info "Creating pull request..."
    local pr_url=$(gh "${gh_args[@]}")
    
    echo "$pr_url"
}

# Main function
main() {
    log_info "Starting security PR creation process..."
    
    # Parse and validate arguments
    parse_args "$@"
    validate_args
    
    # Check prerequisites
    check_git_repo
    check_gh_cli
    
    # Change to project directory
    cd "$PROJECT_DIR"
    
    # Process based on fix type
    case "$FIX_TYPE" in
        "oss")
            process_security_fixes "oss"
            ;;
        "snyk")
            process_security_fixes "snyk"
            ;;
        "all")
            process_security_fixes "oss"
            process_security_fixes "snyk"
            ;;
    esac
    
    log_success "Security PR creation process completed!"
}

# Process security fixes for a specific type
process_security_fixes() {
    local fix_type="$1"
    
    log_info "Processing $fix_type security fixes..."
    
    # Parse scan results
    local vuln_count=$(parse_scan_results "$fix_type")
    log_info "Found $vuln_count vulnerabilities in $fix_type scan results"
    
    # Skip if no vulnerabilities and not forced
    if [[ "$vuln_count" -eq 0 && "$FORCE_CREATE" != "true" ]]; then
        log_warning "No vulnerabilities found for $fix_type, skipping PR creation"
        return 0
    fi
    
    # Create branch
    local branch_name=$(create_security_branch "$fix_type")
    
    # Apply fixes
    local changes_made
    case "$fix_type" in
        "oss")
            changes_made=$(apply_oss_fixes)
            ;;
        "snyk")
            changes_made=$(apply_snyk_fixes)
            ;;
    esac
    
    # Check if changes were made
    if [[ "$changes_made" != "true" && "$FORCE_CREATE" != "true" ]]; then
        log_warning "No changes made for $fix_type fixes, cleaning up branch"
        git checkout main
        git branch -D "$branch_name"
        return 0
    fi
    
    # Check if there are actual git changes
    if [[ -z "$(git status --porcelain)" && "$FORCE_CREATE" != "true" ]]; then
        log_warning "No git changes detected for $fix_type fixes, cleaning up branch"
        git checkout main
        git branch -D "$branch_name"
        return 0
    fi
    
    # Commit changes
    commit_changes "$fix_type" "$vuln_count"
    
    # Push branch
    log_info "Pushing branch to remote..."
    git push origin "$branch_name"
    
    # Create PR
    local pr_url=$(create_pull_request "$fix_type" "$vuln_count" "$branch_name")
    
    log_success "Created pull request: $pr_url"
    
    # Return to main branch
    git checkout main
}

# Run main function with all arguments
main "$@"