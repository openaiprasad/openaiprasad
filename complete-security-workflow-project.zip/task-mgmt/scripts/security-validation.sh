#!/bin/bash

# Security Validation Script for Task Management Application
# This script validates the security configuration and identifies potential issues

set -e

echo "🔐 Task Management Security Validation Script"
echo "=============================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Counters
PASSED=0
FAILED=0
WARNINGS=0

# Function to print status
print_status() {
    local status=$1
    local message=$2
    
    case $status in
        "PASS")
            echo -e "${GREEN}✓ PASS${NC}: $message"
            ((PASSED++))
            ;;
        "FAIL")
            echo -e "${RED}✗ FAIL${NC}: $message"
            ((FAILED++))
            ;;
        "WARN")
            echo -e "${YELLOW}⚠ WARN${NC}: $message"
            ((WARNINGS++))
            ;;
    esac
}

echo ""
echo "1. Checking for hardcoded secrets..."

# Check for hardcoded JWT secrets
if grep -r "private String secret = " src/ 2>/dev/null | grep -v "SecureJwtUtil" | grep -q "taskmgmt"; then
    print_status "FAIL" "Hardcoded JWT secret found in code"
else
    print_status "PASS" "No hardcoded JWT secrets found"
fi

# Check for hardcoded passwords
if grep -r -i "password.*=" src/ 2>/dev/null | grep -v "passwordEncoder" | grep -q "\""; then
    print_status "WARN" "Potential hardcoded passwords found"
else
    print_status "PASS" "No hardcoded passwords found"
fi

echo ""
echo "2. Checking dependency versions..."

# Check Spring Boot version
SPRING_VERSION=$(grep -A1 "spring-boot-starter-parent" pom.xml | grep "<version>" | sed 's/.*<version>\(.*\)<\/version>.*/\1/' | tr -d '[:space:]')
if [[ "$SPRING_VERSION" < "3.0.0" ]]; then
    print_status "FAIL" "Spring Boot version $SPRING_VERSION is outdated (< 3.0.0)"
else
    print_status "PASS" "Spring Boot version $SPRING_VERSION is acceptable"
fi

# Check Java version
JAVA_VERSION=$(grep -A1 "<java.version>" pom.xml | grep -v "java.version" | sed 's/.*>\(.*\)<.*/\1/' | tr -d '[:space:]')
if [[ "$JAVA_VERSION" < "17" ]]; then
    print_status "FAIL" "Java version $JAVA_VERSION is outdated (< 17)"
else
    print_status "PASS" "Java version $JAVA_VERSION is acceptable"
fi

# Check JWT library version
if grep -q "jjwt.*0\.9\." pom.xml; then
    print_status "FAIL" "JWT library version is outdated (0.9.x)"
elif grep -q "jjwt-api" pom.xml; then
    print_status "PASS" "JWT library is using modern version"
else
    print_status "WARN" "JWT library version could not be determined"
fi

echo ""
echo "3. Checking security configuration..."

# Check for CSRF disabled
if grep -q "csrf().disable()" src/main/java/com/taskmgmt/security/*.java; then
    print_status "WARN" "CSRF protection is disabled (acceptable for stateless APIs)"
fi

# Check for security headers
if grep -q "frameOptions().deny()" src/main/java/com/taskmgmt/security/*.java; then
    print_status "PASS" "X-Frame-Options security header configured"
else
    print_status "FAIL" "X-Frame-Options security header not configured"
fi

if grep -q "contentTypeOptions()" src/main/java/com/taskmgmt/security/*.java; then
    print_status "PASS" "X-Content-Type-Options security header configured"
else
    print_status "FAIL" "X-Content-Type-Options security header not configured"
fi

if grep -q "httpStrictTransportSecurity" src/main/java/com/taskmgmt/security/*.java; then
    print_status "PASS" "HSTS security header configured"
else
    print_status "FAIL" "HSTS security header not configured"
fi

echo ""
echo "4. Checking for environment variable usage..."

# Check for environment variable usage in JWT
if grep -q "@Value.*jwt.secret" src/main/java/com/taskmgmt/security/*.java; then
    print_status "PASS" "JWT secret uses environment variable"
else
    print_status "FAIL" "JWT secret does not use environment variable"
fi

# Check for database configuration
if grep -q "DATABASE_URL" src/main/resources/application*.properties; then
    print_status "PASS" "Database URL uses environment variable"
else
    print_status "WARN" "Database URL may not use environment variable"
fi

echo ""
echo "5. Checking for security testing..."

# Check for security tests
if [ -f "src/test/java/com/taskmgmt/security/SecurityConfigTest.java" ]; then
    print_status "PASS" "Security tests are present"
else
    print_status "FAIL" "Security tests are missing"
fi

# Check for OWASP dependency check
if grep -q "dependency-check-maven" pom.xml; then
    print_status "PASS" "OWASP dependency check plugin configured"
else
    print_status "WARN" "OWASP dependency check plugin not configured"
fi

echo ""
echo "6. Checking application properties..."

# Check for debug mode
if grep -q "debug=true" src/main/resources/application*.properties; then
    print_status "FAIL" "Debug mode is enabled"
else
    print_status "PASS" "Debug mode is not explicitly enabled"
fi

# Check for H2 console
if grep -q "h2.console.enabled=true" src/main/resources/application*.properties; then
    print_status "FAIL" "H2 console is enabled (security risk in production)"
else
    print_status "PASS" "H2 console is not explicitly enabled"
fi

echo ""
echo "7. Checking for production readiness..."

# Check for production profile
if [ -f "src/main/resources/application-prod.properties" ]; then
    print_status "PASS" "Production profile configuration exists"
else
    print_status "WARN" "Production profile configuration missing"
fi

# Check for HTTPS configuration
if grep -q "server.ssl.enabled" src/main/resources/application*.properties; then
    print_status "PASS" "HTTPS configuration present"
else
    print_status "WARN" "HTTPS configuration not found"
fi

echo ""
echo "8. Running quick security scans..."

# Check for common security anti-patterns
echo "Checking for common security issues..."

# SQL injection patterns
if grep -r "Statement.*execute" src/ 2>/dev/null | grep -v "PreparedStatement"; then
    print_status "WARN" "Potential SQL injection risk found (raw Statement usage)"
fi

# XSS patterns
if grep -r "innerHTML\|document.write" src/ 2>/dev/null; then
    print_status "WARN" "Potential XSS risk found (innerHTML/document.write usage)"
fi

# Insecure random
if grep -r "Math.random\|Random()" src/ 2>/dev/null; then
    print_status "WARN" "Insecure random number generation found"
fi

echo ""
echo "=============================================="
echo "Security Validation Summary:"
echo -e "${GREEN}Passed: $PASSED${NC}"
echo -e "${YELLOW}Warnings: $WARNINGS${NC}"
echo -e "${RED}Failed: $FAILED${NC}"

if [ $FAILED -gt 0 ]; then
    echo ""
    echo -e "${RED}❌ Security validation FAILED. Please address the failed checks before deployment.${NC}"
    exit 1
elif [ $WARNINGS -gt 0 ]; then
    echo ""
    echo -e "${YELLOW}⚠️  Security validation completed with warnings. Review warnings before production deployment.${NC}"
    exit 0
else
    echo ""
    echo -e "${GREEN}✅ Security validation PASSED. Application appears to be secure.${NC}"
    exit 0
fi