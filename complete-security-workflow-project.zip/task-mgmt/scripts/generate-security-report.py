#!/usr/bin/env python3
"""
Security Report Generator
Generates comprehensive security reports from OSS and Snyk scan results
"""

import json
import argparse
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any
import base64

try:
    import matplotlib.pyplot as plt
    import matplotlib
    matplotlib.use('Agg')  # Use non-interactive backend
except ImportError:
    print("Warning: matplotlib not available, charts will be disabled")
    plt = None

def load_json_file(file_path: str) -> Dict[str, Any]:
    """Load JSON file safely"""
    try:
        with open(file_path, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Warning: Could not load {file_path}: {e}")
        return {}

def parse_trivy_results(trivy_file: str) -> Dict[str, Any]:
    """Parse Trivy scan results"""
    data = load_json_file(trivy_file)
    vulnerabilities = []
    
    for result in data.get('Results', []):
        for vuln in result.get('Vulnerabilities', []):
            vulnerabilities.append({
                'id': vuln.get('VulnerabilityID', 'Unknown'),
                'severity': vuln.get('Severity', 'Unknown'),
                'title': vuln.get('Title', 'Unknown'),
                'description': vuln.get('Description', ''),
                'package': vuln.get('PkgName', 'Unknown'),
                'installed_version': vuln.get('InstalledVersion', ''),
                'fixed_version': vuln.get('FixedVersion', ''),
                'source': 'Trivy'
            })
    
    return {
        'tool': 'Trivy',
        'vulnerabilities': vulnerabilities,
        'total_count': len(vulnerabilities)
    }

def parse_pip_audit_results(pip_audit_file: str) -> Dict[str, Any]:
    """Parse pip-audit scan results"""
    data = load_json_file(pip_audit_file)
    vulnerabilities = []
    
    for vuln in data.get('vulnerabilities', []):
        vulnerabilities.append({
            'id': vuln.get('id', 'Unknown'),
            'severity': 'High',  # pip-audit doesn't provide severity
            'title': vuln.get('description', 'Unknown'),
            'description': vuln.get('description', ''),
            'package': vuln.get('package', 'Unknown'),
            'installed_version': vuln.get('installed_version', ''),
            'fixed_version': ', '.join(vuln.get('fixed_versions', [])),
            'source': 'pip-audit'
        })
    
    return {
        'tool': 'pip-audit',
        'vulnerabilities': vulnerabilities,
        'total_count': len(vulnerabilities)
    }

def parse_owasp_results(owasp_file: str) -> Dict[str, Any]:
    """Parse OWASP Dependency Check results"""
    data = load_json_file(owasp_file)
    vulnerabilities = []
    
    for dependency in data.get('dependencies', []):
        for vuln in dependency.get('vulnerabilities', []):
            vulnerabilities.append({
                'id': vuln.get('name', 'Unknown'),
                'severity': vuln.get('severity', 'Unknown'),
                'title': vuln.get('description', 'Unknown'),
                'description': vuln.get('description', ''),
                'package': dependency.get('fileName', 'Unknown'),
                'installed_version': '',
                'fixed_version': '',
                'source': 'OWASP'
            })
    
    return {
        'tool': 'OWASP Dependency Check',
        'vulnerabilities': vulnerabilities,
        'total_count': len(vulnerabilities)
    }

def parse_snyk_results(snyk_file: str) -> Dict[str, Any]:
    """Parse Snyk scan results"""
    data = load_json_file(snyk_file)
    vulnerabilities = []
    
    for vuln in data.get('vulnerabilities', []):
        vulnerabilities.append({
            'id': vuln.get('id', 'Unknown'),
            'severity': vuln.get('severity', 'Unknown').title(),
            'title': vuln.get('title', 'Unknown'),
            'description': vuln.get('description', ''),
            'package': vuln.get('packageName', 'Unknown'),
            'installed_version': vuln.get('version', ''),
            'fixed_version': ', '.join(vuln.get('fixedIn', [])),
            'source': 'Snyk'
        })
    
    return {
        'tool': 'Snyk',
        'vulnerabilities': vulnerabilities,
        'total_count': len(vulnerabilities)
    }

def generate_severity_chart(vulnerabilities: List[Dict[str, Any]]) -> str:
    """Generate severity distribution chart"""
    if not plt:
        return ""
    
    severity_counts = {}
    for vuln in vulnerabilities:
        severity = vuln.get('severity', 'Unknown').title()
        severity_counts[severity] = severity_counts.get(severity, 0) + 1
    
    if not severity_counts:
        return ""
    
    # Create pie chart
    fig, ax = plt.subplots(figsize=(8, 6))
    colors = {
        'Critical': '#dc3545',
        'High': '#fd7e14',
        'Medium': '#ffc107',
        'Low': '#28a745',
        'Unknown': '#6c757d'
    }
    
    labels = list(severity_counts.keys())
    sizes = list(severity_counts.values())
    chart_colors = [colors.get(label, '#6c757d') for label in labels]
    
    ax.pie(sizes, labels=labels, colors=chart_colors, autopct='%1.1f%%', startangle=90)
    ax.set_title('Vulnerability Distribution by Severity')
    
    # Save to base64
    import io
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', dpi=150)
    buffer.seek(0)
    chart_data = base64.b64encode(buffer.getvalue()).decode()
    plt.close()
    
    return f"data:image/png;base64,{chart_data}"

def generate_tool_chart(scan_results: List[Dict[str, Any]]) -> str:
    """Generate tool comparison chart"""
    if not plt:
        return ""
    
    tools = [result['tool'] for result in scan_results]
    counts = [result['total_count'] for result in scan_results]
    
    if not tools:
        return ""
    
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.bar(tools, counts, color=['#007bff', '#28a745', '#ffc107', '#dc3545'])
    
    ax.set_title('Vulnerabilities Found by Tool')
    ax.set_ylabel('Number of Vulnerabilities')
    ax.set_xlabel('Security Tools')
    
    # Add value labels on bars
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{int(height)}', ha='center', va='bottom')
    
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # Save to base64
    import io
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight', dpi=150)
    buffer.seek(0)
    chart_data = base64.b64encode(buffer.getvalue()).decode()
    plt.close()
    
    return f"data:image/png;base64,{chart_data}"

def generate_html_report(scan_results: List[Dict[str, Any]], theme: str = 'dark') -> str:
    """Generate HTML security report"""
    
    # Combine all vulnerabilities
    all_vulnerabilities = []
    for result in scan_results:
        all_vulnerabilities.extend(result['vulnerabilities'])
    
    # Calculate statistics
    total_vulns = len(all_vulnerabilities)
    severity_stats = {}
    for vuln in all_vulnerabilities:
        severity = vuln.get('severity', 'Unknown').title()
        severity_stats[severity] = severity_stats.get(severity, 0) + 1
    
    # Generate charts
    severity_chart = generate_severity_chart(all_vulnerabilities)
    tool_chart = generate_tool_chart(scan_results)
    
    # Theme colors
    if theme == 'dark':
        bg_color = '#1a1a1a'
        text_color = '#ffffff'
        card_bg = '#2d2d2d'
        border_color = '#404040'
    else:
        bg_color = '#ffffff'
        text_color = '#333333'
        card_bg = '#f8f9fa'
        border_color = '#dee2e6'
    
    html_template = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Security Scan Report</title>
        <style>
            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 0;
                padding: 20px;
                background-color: {bg_color};
                color: {text_color};
                line-height: 1.6;
            }}
            .container {{
                max-width: 1200px;
                margin: 0 auto;
            }}
            .header {{
                text-align: center;
                margin-bottom: 30px;
                padding: 20px;
                background-color: {card_bg};
                border-radius: 8px;
                border: 1px solid {border_color};
            }}
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin-bottom: 30px;
            }}
            .stat-card {{
                background-color: {card_bg};
                padding: 20px;
                border-radius: 8px;
                text-align: center;
                border: 1px solid {border_color};
            }}
            .stat-number {{
                font-size: 2em;
                font-weight: bold;
                margin-bottom: 5px;
            }}
            .critical {{ color: #dc3545; }}
            .high {{ color: #fd7e14; }}
            .medium {{ color: #ffc107; }}
            .low {{ color: #28a745; }}
            .charts {{
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-bottom: 30px;
            }}
            .chart-container {{
                background-color: {card_bg};
                padding: 20px;
                border-radius: 8px;
                text-align: center;
                border: 1px solid {border_color};
            }}
            .chart-container img {{
                max-width: 100%;
                height: auto;
            }}
            .vulnerabilities {{
                background-color: {card_bg};
                padding: 20px;
                border-radius: 8px;
                border: 1px solid {border_color};
            }}
            .vuln-table {{
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }}
            .vuln-table th,
            .vuln-table td {{
                padding: 12px;
                text-align: left;
                border-bottom: 1px solid {border_color};
            }}
            .vuln-table th {{
                background-color: {bg_color};
                font-weight: bold;
            }}
            .severity-badge {{
                padding: 4px 8px;
                border-radius: 4px;
                font-size: 0.8em;
                font-weight: bold;
                text-transform: uppercase;
            }}
            .severity-critical {{
                background-color: #dc3545;
                color: white;
            }}
            .severity-high {{
                background-color: #fd7e14;
                color: white;
            }}
            .severity-medium {{
                background-color: #ffc107;
                color: black;
            }}
            .severity-low {{
                background-color: #28a745;
                color: white;
            }}
            .footer {{
                text-align: center;
                margin-top: 30px;
                padding: 20px;
                background-color: {card_bg};
                border-radius: 8px;
                border: 1px solid {border_color};
            }}
            @media (max-width: 768px) {{
                .charts {{
                    grid-template-columns: 1fr;
                }}
                .vuln-table {{
                    font-size: 0.9em;
                }}
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔐 Security Scan Report</h1>
                <p>Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}</p>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number">{total_vulns}</div>
                    <div>Total Vulnerabilities</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number critical">{severity_stats.get('Critical', 0)}</div>
                    <div>Critical</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number high">{severity_stats.get('High', 0)}</div>
                    <div>High</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number medium">{severity_stats.get('Medium', 0)}</div>
                    <div>Medium</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number low">{severity_stats.get('Low', 0)}</div>
                    <div>Low</div>
                </div>
            </div>
            
            <div class="charts">
                <div class="chart-container">
                    <h3>Vulnerability Distribution by Severity</h3>
                    {f'<img src="{severity_chart}" alt="Severity Distribution Chart">' if severity_chart else '<p>Chart not available</p>'}
                </div>
                <div class="chart-container">
                    <h3>Vulnerabilities by Tool</h3>
                    {f'<img src="{tool_chart}" alt="Tool Comparison Chart">' if tool_chart else '<p>Chart not available</p>'}
                </div>
            </div>
            
            <div class="vulnerabilities">
                <h2>Vulnerability Details</h2>
                <table class="vuln-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Severity</th>
                            <th>Title</th>
                            <th>Package</th>
                            <th>Version</th>
                            <th>Fix</th>
                            <th>Source</th>
                        </tr>
                    </thead>
                    <tbody>
    """
    
    # Add vulnerability rows
    for vuln in sorted(all_vulnerabilities, key=lambda x: {'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3}.get(x.get('severity', 'Unknown'), 4)):
        severity = vuln.get('severity', 'Unknown').title()
        severity_class = f"severity-{severity.lower()}"
        
        html_template += f"""
                        <tr>
                            <td>{vuln.get('id', 'N/A')}</td>
                            <td><span class="severity-badge {severity_class}">{severity}</span></td>
                            <td>{vuln.get('title', 'N/A')[:100]}{'...' if len(vuln.get('title', '')) > 100 else ''}</td>
                            <td>{vuln.get('package', 'N/A')}</td>
                            <td>{vuln.get('installed_version', 'N/A')}</td>
                            <td>{vuln.get('fixed_version', 'N/A')}</td>
                            <td>{vuln.get('source', 'N/A')}</td>
                        </tr>
        """
    
    html_template += f"""
                    </tbody>
                </table>
            </div>
            
            <div class="footer">
                <p>Report generated by Security Scanning Workflow</p>
                <p>Tools used: {', '.join([result['tool'] for result in scan_results])}</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    return html_template

def generate_json_summary(scan_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generate JSON summary of scan results"""
    all_vulnerabilities = []
    for result in scan_results:
        all_vulnerabilities.extend(result['vulnerabilities'])
    
    severity_stats = {}
    for vuln in all_vulnerabilities:
        severity = vuln.get('severity', 'Unknown').title()
        severity_stats[severity] = severity_stats.get(severity, 0) + 1
    
    return {
        'scan_date': datetime.now().isoformat(),
        'total_vulnerabilities': len(all_vulnerabilities),
        'severity_breakdown': severity_stats,
        'tools_used': [result['tool'] for result in scan_results],
        'tool_results': {result['tool']: result['total_count'] for result in scan_results},
        'summary': {
            'critical_count': severity_stats.get('Critical', 0),
            'high_count': severity_stats.get('High', 0),
            'medium_count': severity_stats.get('Medium', 0),
            'low_count': severity_stats.get('Low', 0),
            'risk_level': 'Critical' if severity_stats.get('Critical', 0) > 0 else
                         'High' if severity_stats.get('High', 0) > 0 else
                         'Medium' if severity_stats.get('Medium', 0) > 0 else
                         'Low' if severity_stats.get('Low', 0) > 0 else 'None'
        }
    }

def main():
    parser = argparse.ArgumentParser(description='Generate security scan report')
    parser.add_argument('--oss-results', required=True, help='Path to OSS scan results directory')
    parser.add_argument('--snyk-results', required=True, help='Path to Snyk scan results directory')
    parser.add_argument('--output', default='security-dashboard.html', help='Output file path')
    parser.add_argument('--format', choices=['html', 'json'], default='html', help='Output format')
    parser.add_argument('--theme', choices=['light', 'dark'], default='dark', help='Report theme')
    
    args = parser.parse_args()
    
    scan_results = []
    
    # Parse OSS results
    oss_dir = Path(args.oss_results)
    if oss_dir.exists():
        # Trivy results
        trivy_file = oss_dir / 'trivy-report.json'
        if trivy_file.exists():
            scan_results.append(parse_trivy_results(str(trivy_file)))
        
        # pip-audit results
        pip_audit_file = oss_dir / 'pip-audit-report.json'
        if pip_audit_file.exists():
            scan_results.append(parse_pip_audit_results(str(pip_audit_file)))
        
        # OWASP results
        owasp_file = oss_dir / 'dependency-check-report.json'
        if owasp_file.exists():
            scan_results.append(parse_owasp_results(str(owasp_file)))
    
    # Parse Snyk results
    snyk_dir = Path(args.snyk_results)
    if snyk_dir.exists():
        snyk_file = snyk_dir / 'snyk-report.json'
        if snyk_file.exists():
            scan_results.append(parse_snyk_results(str(snyk_file)))
    
    if not scan_results:
        print("No scan results found!")
        sys.exit(1)
    
    # Generate report
    if args.format == 'html':
        report_content = generate_html_report(scan_results, args.theme)
        with open(args.output, 'w') as f:
            f.write(report_content)
    else:
        report_content = generate_json_summary(scan_results)
        with open(args.output, 'w') as f:
            json.dump(report_content, f, indent=2)
    
    # Always generate JSON summary
    summary = generate_json_summary(scan_results)
    with open('security-summary.json', 'w') as f:
        json.dump(summary, f, indent=2)
    
    print(f"Security report generated: {args.output}")
    print(f"Total vulnerabilities found: {summary['total_vulnerabilities']}")
    print(f"Risk level: {summary['summary']['risk_level']}")

if __name__ == '__main__':
    main()