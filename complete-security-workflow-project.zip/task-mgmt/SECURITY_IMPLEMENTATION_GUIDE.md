# Security Implementation Guide

## Overview

This guide provides step-by-step instructions for implementing the security improvements identified in the security analysis. Follow these steps in order to ensure a secure deployment.

## Phase 1: Critical Security Fixes (IMMEDIATE)

### 1.1 Replace Hardcoded JWT Secret

**Current Issue**: JWT secret is hardcoded in `JwtUtil.java`

**Solution**:
1. Replace `JwtUtil.java` with `SecureJwtUtil.java`
2. Update `application.properties`:
   ```properties
   jwt.secret=${JWT_SECRET:your-very-long-and-secure-secret-key-that-should-be-at-least-256-bits}
   jwt.expiration=${JWT_EXPIRATION:3600000}
   ```
3. Set environment variable:
   ```bash
   export JWT_SECRET="your-super-secure-256-bit-secret-key-here"
   ```

### 1.2 Update Security Configuration

**Current Issue**: Weak security configuration in `WebSecurityConfig.java`

**Solution**:
1. Replace `WebSecurityConfig.java` with `SecurityConfig.java`
2. Update CORS configuration to use environment variables
3. Enable proper security headers

### 1.3 Environment Variables Setup

Create `.env` file (DO NOT commit to version control):
```bash
# JWT Configuration
JWT_SECRET=your-super-secure-256-bit-secret-key-here-make-it-very-long
JWT_EXPIRATION=3600000

# Database Configuration
DATABASE_URL=jdbc:postgresql://localhost:5432/taskmgmt
DB_USERNAME=taskmgmt_user
DB_PASSWORD=secure_password_here

# CORS Configuration
CORS_ALLOWED_ORIGINS=http://localhost:4200,https://yourdomain.com
```

## Phase 2: Dependency Updates (HIGH PRIORITY)

### 2.1 Update Maven Dependencies

Replace `pom.xml` with `pom-secure.xml`:

**Key Updates**:
- Spring Boot: 2.5.9 → 3.2.0
- Java: 1.8 → 17
- JWT: 0.9.1 → 0.12.3
- JasperReports: 6.20.0 → 6.20.6

### 2.2 Database Security

**For Production**:
1. Replace H2 with PostgreSQL
2. Update `application-prod.properties`:
   ```properties
   spring.datasource.url=${DATABASE_URL}
   spring.datasource.username=${DB_USERNAME}
   spring.datasource.password=${DB_PASSWORD}
   spring.datasource.driver-class-name=org.postgresql.Driver
   
   # Connection pool security
   spring.datasource.hikari.maximum-pool-size=10
   spring.datasource.hikari.minimum-idle=5
   spring.datasource.hikari.connection-timeout=20000
   ```

## Phase 3: Security Headers and HTTPS (MEDIUM PRIORITY)

### 3.1 Security Headers Implementation

Already implemented in `SecurityConfig.java`:
- X-Frame-Options: DENY
- X-Content-Type-Options: nosniff
- Strict-Transport-Security
- Referrer-Policy

### 3.2 HTTPS Configuration

Add to `application-prod.properties`:
```properties
# HTTPS Configuration
server.ssl.enabled=true
server.ssl.key-store=classpath:keystore.p12
server.ssl.key-store-password=${SSL_KEYSTORE_PASSWORD}
server.ssl.key-store-type=PKCS12
server.ssl.key-alias=tomcat

# Redirect HTTP to HTTPS
server.ssl.enabled-protocols=TLSv1.2,TLSv1.3
```

## Phase 4: Input Validation and Error Handling

### 4.1 Input Validation

Add validation annotations to DTOs:
```java
public class TaskDTO {
    @NotBlank(message = "Title is required")
    @Size(max = 100, message = "Title must not exceed 100 characters")
    private String title;
    
    @Size(max = 500, message = "Description must not exceed 500 characters")
    private String description;
}
```

### 4.2 Global Exception Handler

Create `GlobalExceptionHandler.java`:
```java
@ControllerAdvice
public class GlobalExceptionHandler {
    
    @ExceptionHandler(SecurityException.class)
    public ResponseEntity<ErrorResponse> handleSecurityException(SecurityException e) {
        // Log security event
        logger.warn("Security exception: {}", e.getMessage());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(new ErrorResponse("Authentication failed"));
    }
}
```

## Phase 5: Security Testing

### 5.1 Run Security Tests

```bash
# Run security-specific tests
mvn test -Dtest=SecurityConfigTest

# Run dependency vulnerability scan
mvn org.owasp:dependency-check-maven:check

# Run static analysis
mvn spotbugs:check
```

### 5.2 Manual Security Testing

1. **Authentication Testing**:
   - Test with invalid JWT tokens
   - Test token expiration
   - Test malformed tokens

2. **Authorization Testing**:
   - Test access to protected endpoints
   - Test role-based access

3. **Input Validation Testing**:
   - Test SQL injection attempts
   - Test XSS attempts
   - Test oversized inputs

## Phase 6: Production Deployment Security

### 6.1 Environment Configuration

**Production Checklist**:
- [ ] JWT secret is 256+ bits and randomly generated
- [ ] Database credentials are secure and rotated
- [ ] HTTPS is enabled with valid certificates
- [ ] Security headers are properly configured
- [ ] CORS is restricted to production domains
- [ ] Debug mode is disabled
- [ ] Actuator endpoints are secured

### 6.2 Monitoring and Logging

Add to `application-prod.properties`:
```properties
# Security Logging
logging.level.org.springframework.security=INFO
logging.level.com.taskmgmt.security=DEBUG

# Actuator Security
management.endpoints.web.exposure.include=health,info,metrics
management.endpoint.health.show-details=when-authorized
management.endpoints.web.base-path=/actuator
```

## Phase 7: Continuous Security

### 7.1 Automated Security Scanning

Add to CI/CD pipeline:
```yaml
# .github/workflows/security.yml
name: Security Scan
on: [push, pull_request]
jobs:
  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run OWASP Dependency Check
        run: mvn org.owasp:dependency-check-maven:check
      - name: Run Security Tests
        run: mvn test -Dtest=*Security*
```

### 7.2 Regular Security Reviews

**Monthly Tasks**:
- [ ] Update dependencies
- [ ] Review security logs
- [ ] Rotate JWT secrets
- [ ] Update security documentation

**Quarterly Tasks**:
- [ ] Penetration testing
- [ ] Security architecture review
- [ ] Compliance audit
- [ ] Security training update

## Security Configuration Summary

The provided `security-config.yml` enables:

1. **Automated Vulnerability Scanning**:
   - OSS scanning with Trivy and OSV
   - Snyk scanning for SCA and code analysis

2. **Automated Security Fixes**:
   - High severity vulnerabilities only
   - No major version bumps
   - Requires tests to pass
   - Limited to 20 files per fix

3. **Pull Request Management**:
   - Per-stage strategy for organized fixes
   - Security team review required
   - Automated labeling

4. **Reporting**:
   - HTML format with dark theme
   - Fails build on critical unfixed vulnerabilities

## Emergency Response

If a critical vulnerability is discovered:

1. **Immediate Actions**:
   - Assess impact and exposure
   - Apply temporary mitigations
   - Notify security team

2. **Short-term Actions**:
   - Deploy security patches
   - Update monitoring rules
   - Communicate with stakeholders

3. **Long-term Actions**:
   - Review security processes
   - Update security documentation
   - Implement additional controls

## Support and Resources

- **OWASP Top 10**: https://owasp.org/www-project-top-ten/
- **Spring Security Documentation**: https://spring.io/projects/spring-security
- **JWT Best Practices**: https://tools.ietf.org/html/rfc8725
- **Security Headers**: https://securityheaders.com/

---

**Last Updated**: 2025-12-13  
**Next Review**: 2026-01-13  
**Version**: 1.0