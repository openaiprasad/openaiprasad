package com.taskmgmt.service;

public class RandomPostGeneratorFactory {

	
	private RandomPostGenerator generator;
	
	public RandomPostGeneratorFactory(RandomPostGenerator generator) {
		this.generator = generator;
	}
}
