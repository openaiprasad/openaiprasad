package com.taskmgmt.service;

public class PlayerDetails {

}
