package com.taskmgmt.service;

public class GameDetails {

}
